---
name: Bug report
about: development/masterでの不具合を報告するissue
title: ''
labels: 'bug'
assignees: ''

---

### 概要

今日は皆さんに残念なお知らせがあります。 :scream:

### 報告者
<!-- 起票者と違う場合  -->

### 再現方法

1.
2.

### 期待する動作
△が表示される

### 実際の動作
△が表示される

### キャプチャ
<!-- 何かあれば  -->

### 参考情報
<!-- 何かあれば  -->
