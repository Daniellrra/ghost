---
name: Feature
about: 新機能についてのissue
title: ''
labels: 'feature'
assignees: ''

---

### 概要 🚀

新規機能の概要

### 詳細 📝

新機能の詳細

### タスク分割 ✅
- [ ] XXXXX
- [ ] XXXXX
- [ ] XXXXX
<!-- 分かる範囲でタスクを細分化 -->

### 参考情報

<!-- 他サービスの類似機能の概要や、Overview/Notionの画像など何かあれば -->