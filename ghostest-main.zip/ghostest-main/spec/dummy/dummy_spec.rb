RSpec.describe 'DummySpec', type: :model do
  it 'returns true' do
    expect(true).to eq(true)
  end
end
