require 'ghostest'
