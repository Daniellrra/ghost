module Ghostest
  class ConfigError < StandardError

  end
end
