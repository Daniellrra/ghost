module Ghostest
  class Error < StandardError

  end
end
